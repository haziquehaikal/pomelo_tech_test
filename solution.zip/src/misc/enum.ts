export enum TransactionStatus {
    PAID = 'PAID',
    UNPAID = 'UNPAID',
}